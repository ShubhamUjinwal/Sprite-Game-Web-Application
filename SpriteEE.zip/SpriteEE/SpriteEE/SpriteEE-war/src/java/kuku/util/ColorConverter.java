/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuku.util;
import business.Sprite;
import java.awt.Color;
import java.util.ArrayList;
import java.util.ListIterator;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import kuku.SpriteController;

/**
 *
 * @author Asus
 */
@FacesConverter("kuku.util.ColorConverter")
public class ColorConverter implements Converter{

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        
        if(value == null || value.length() == 0){
            return null;
        }
        
        int count=0;
        ArrayList<Character> list = new ArrayList<>();
        StringBuilder r = new StringBuilder();
        StringBuilder g = new StringBuilder();
        StringBuilder b = new StringBuilder();
        char a = 0;
        for(int i=0; i<value.length(); i++) {
                list.add(value.charAt(i));
        }

        ListIterator iterator = list.listIterator(); 
        while(iterator.hasNext()) {
            if((char)iterator.next() == '=') {
                while(a!=',' && a!=']') {
                    a = (char)iterator.next();
                    if(a!=',' && a!=']'&&count==0) {
                            r.append(a);
                    }
                    if(a!=',' && a!=']'&&count==1) {
                            g.append(a);
                    }
                    if(a!=',' && a!=']'&count==2) {
                            b.append(a);
                    }
                }
                a=0;
                count++;
            }
        }
        
        Color c = new Color(Integer.parseInt(r.toString()),Integer.parseInt(g.toString()),Integer.parseInt(b.toString()));
         SpriteController sc = (SpriteController) context.getApplication().getELResolver().
                    getValue(context.getELContext(), null, "spriteController");

        sc.getSelected().setColor(c);
       // sc.current.setColor(c);
        return c;
        
        
    }

    @Override
    public String getAsString(FacesContext arg0, UIComponent arg1, Object arg2) {
        
        Color color = (Color)arg2;
        return color.toString();
        
    }
    
}
